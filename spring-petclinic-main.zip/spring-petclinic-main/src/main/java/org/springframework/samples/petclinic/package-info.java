@NullMarked
package org.springframework.samples.petclinic;

import org.jspecify.annotations.NullMarked;

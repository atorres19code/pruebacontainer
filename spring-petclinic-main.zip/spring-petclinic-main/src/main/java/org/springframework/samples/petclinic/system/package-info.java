@NullMarked
package org.springframework.samples.petclinic.system;

import org.jspecify.annotations.NullMarked;

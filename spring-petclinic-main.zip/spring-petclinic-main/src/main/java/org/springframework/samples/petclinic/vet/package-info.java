@NullMarked
package org.springframework.samples.petclinic.vet;

import org.jspecify.annotations.NullMarked;
